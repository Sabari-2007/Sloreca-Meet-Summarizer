# 🚀 Complete Setup Guide - Meeting Summarizer Extension

**Total Setup Time: 10-15 minutes**

## Part 1: Create Project Structure (5 minutes)

### Step 1.1: Create Main Folder

```bash
# On Windows
mkdir meeting-summarizer-extension
cd meeting-summarizer-extension

# On Mac/Linux
mkdir meeting-summarizer-extension
cd meeting-summarizer-extension
```

### Step 1.2: Create Subfolder Structure

```bash
# Create all subdirectories
mkdir -p src/popup
mkdir -p src/content
mkdir -p src/background
mkdir -p src/options
mkdir icons
```

### Step 1.3: Your Folder Should Look Like

```
meeting-summarizer-extension/
├── src/
│   ├── popup/
│   ├── content/
│   ├── background/
│   └── options/
├── icons/
├── manifest.json
└── README.md
```

## Part 2: Copy Files (2 minutes)

### Copy These Files to Correct Locations:

```
manifest.json                    → Root folder
README.md                        → Root folder
src/popup/popup.html            → src/popup/
src/popup/popup.js              → src/popup/
src/popup/popup.css             → src/popup/
src/content/content.js          → src/content/
src/background/service-worker.js → src/background/
src/options/options.html        → src/options/
src/options/options.js          → src/options/
.gitignore                       → Root folder
```

### Using Terminal (Recommended)

```bash
# From project root
# All files should be in correct folders automatically if you follow structure
```

### Using File Explorer (Alternative)

1. Right-click folder → New File
2. Copy paste code from provided files
3. Save with correct name and extension

## Part 3: Create Icons (Optional but Recommended) (3 minutes)

### Create Simple Icons

For now, you can use text placeholders. Create these files:

**icons/icon-16.png, icon-48.png, icon-128.png**

**Using Online Tool:**
1. Go to https://favicon-generator.org/
2. Upload any image or create simple text logo
3. Download all sizes
4. Save as icon-16.png, icon-48.png, icon-128.png
5. Place in `icons/` folder

**Or Use Placeholder:**

If you don't have icons yet, extension will still work. You can add them later.

## Part 4: Test Locally (3 minutes)

### Step 4.1: Open Chrome Extensions

1. Open **Google Chrome**
2. Go to: `chrome://extensions/`
3. You should see this page:

```
Extensions
[Search box]
[Developer mode] toggle in top-right
```

### Step 4.2: Enable Developer Mode

1. Look for **"Developer mode"** toggle (top-right)
2. Click it to turn **ON** (should be blue)

### Step 4.3: Load Extension

1. Click **"Load unpacked"** button (appears after developer mode on)
2. Navigate to your `meeting-summarizer-extension` folder
3. Click **"Select Folder"**

### Step 4.4: Verify Installation

You should see:
```
Meeting Summarizer
Automatically summarize Google Meet, Zoom, and Teams meetings using AI
[ON] [Remove] [Details]
```

✅ If you see this, installation is successful!

## Part 5: Test the Extension (3 minutes)

### Step 5.1: Open a Test Meeting

- Go to https://meet.google.com
- Start a new meeting
- Copy the meeting code
- Open in second window/incognito to simulate 2 participants
- Say something like: "This is a test meeting about project management"

### Step 5.2: Click Extension

1. Click the Meeting Summarizer icon in toolbar
2. You should see popup with:
   - 📹 Meeting Summarizer header
   - Status: "Ready"
   - 🔴 Start Capturing button
   - ⏹️ Stop & Summarize button (disabled)

✅ If popup appears, extension is working!

### Step 5.3: Test Capture

1. Click **"🔴 Start Capturing"** button
2. Status should change to "🔴 Recording..."
3. Speak in the meeting for 20-30 seconds
4. Click **"⏹️ Stop & Summarize"**

### Step 5.4: Wait for Results

You'll see:
```
⏳ Processing transcript...
This may take 10-30 seconds
```

Then:
```
📋 Summary
[Summary text]

🎯 Key Points
• Point 1
• Point 2

✅ Action Items
☐ Owner: Action
```

✅ If you see summary, everything is working!

## Part 6: Configure API Keys (Optional) (2 minutes)

### To Use Claude API (Optional - Better Quality)

1. In extension popup, click **⚙️ Settings**
2. You'll see options page
3. Select **"Claude API"** from dropdown
4. Go to https://console.anthropic.com
5. Sign up (takes 2 minutes)
6. You'll get **$5 free credit** automatically
7. Navigate to: Settings → API Keys
8. Copy your key
9. Paste in extension settings
10. Click **"Save Settings"**
11. Click **"Test API"** button
12. Should see: **✅ API connection successful!**

### To Use HuggingFace (Free - No Key Needed)

- Default option
- No setup required
- Works immediately
- Slower but free

## Part 7: Verify Everything Works

### Checklist

- [ ] Extension appears in Chrome toolbar
- [ ] Popup opens when you click icon
- [ ] Start Capturing button works
- [ ] Captions appear in meeting (if enabled)
- [ ] Stop button captures captions
- [ ] Summary is generated (takes 10-30 sec)
- [ ] You can download or copy summary
- [ ] Settings page opens
- [ ] Can select different AI provider
- [ ] (Optional) Claude API key test passes

**If all checked: You're ready to submit!**

## Part 8: Common Issues & Fixes

### Issue: "Please open a meeting first"

```
✅ Fix:
1. Make sure you're on Google Meet/Zoom/Teams
2. Check URL matches these patterns:
   - https://meet.google.com/*
   - https://zoom.us/*
   - https://teams.microsoft.com/*
3. Close and reopen popup
```

### Issue: "No captions appearing"

```
✅ Fix:
1. For Google Meet:
   - Click Settings ⚙️ → Captions
   - Toggle "On"
2. For Zoom:
   - Click "CC" button in controls
3. For Teams:
   - Settings → Captions → On
4. Try speaking again
```

### Issue: Extension not showing in toolbar

```
✅ Fix:
1. Go to chrome://extensions/
2. Find "Meeting Summarizer"
3. Check it's enabled (toggle is ON)
4. If missing: "Load unpacked" again
5. Reload Chrome if needed
```

### Issue: "API Error" when summarizing

```
✅ Fix:
1. Check internet connection
2. If using Claude: verify API key is correct
3. Try again (may be temp issue)
4. Try HuggingFace instead (if Claude API fails)
5. Check DevTools console for details (F12)
```

### Issue: Manifest Errors

```
✅ Fix:
1. Check all file paths are exact
2. Make sure manifest.json is in ROOT folder
3. No extra spaces or special characters in names
4. Reload extension: click refresh icon
```

## Part 9: Prepare for Submission

### Files to Include

```
meet-summarizer-extension/
├── manifest.json
├── README.md
├── .gitignore
├── src/
│   ├── popup/
│   │   ├── popup.html
│   │   ├── popup.js
│   │   └── popup.css
│   ├── content/
│   │   └── content.js
│   ├── background/
│   │   └── service-worker.js
│   └── options/
│       ├── options.html
│       └── options.js
└── icons/
    ├── icon-16.png
    ├── icon-48.png
    └── icon-128.png
```

### Create GitHub Repo (Optional but Recommended)

```bash
# Initialize git
git init
git add .
git commit -m "Initial commit: Meeting Summarizer extension"

# Create repo on GitHub
# Then:
git remote add origin https://github.com/yourusername/meeting-summarizer-extension.git
git push -u origin main
```

### Submit This:

1. **Link to GitHub repo** (or ZIP file)
2. **README with instructions**
3. **Screenshots** (optional)
4. **Demo video** (optional but impactful)

## Part 10: Demo Video Script (Optional)

If you want to create a demo video (highly recommended):

```
Script (30 seconds):

"This is Meeting Summarizer extension.

1. I click the extension icon here
2. See the popup with Start Capturing button
3. I click it, and it says 'Recording...'
4. While in the meeting, I talk for 20 seconds
5. I click Stop & Summarize
6. Extension shows 'Processing...'
7. In 10 seconds, I have:
   - Executive summary
   - Key points extracted
   - Action items with owners
8. I can download as JSON or copy
9. Perfect for busy professionals!

Try it now - completely free!"
```

## ✅ Final Checklist Before Submission

- [ ] All files copied correctly
- [ ] Extension loads without errors
- [ ] Popup displays properly
- [ ] Can capture captions
- [ ] Can generate summary
- [ ] Settings page works
- [ ] Download/copy works
- [ ] Tested on at least one platform (Meet/Zoom/Teams)
- [ ] README is complete
- [ ] .gitignore exists
- [ ] GitHub repo created (optional)
- [ ] No API keys in code
- [ ] All JavaScript files have no errors (check console)

## 🎓 What You've Built

A professional browser extension that:
- ✅ Injects into meeting pages
- ✅ Captures live captions in real-time
- ✅ Calls cloud APIs for AI processing
- ✅ Handles errors gracefully
- ✅ Stores user preferences
- ✅ Has a polished UI
- ✅ Works completely offline for capture
- ✅ Uses free and premium APIs

## 📊 Technical Stack

| Component | Technology |
|-----------|-----------|
| Frontend | HTML5, CSS3, Vanilla JS |
| Communication | Chrome Runtime API |
| AI | Claude API + HuggingFace |
| Storage | Chrome Storage API |
| Architecture | Manifest v3 (Latest) |

## 🎯 Ready to Submit!

Your extension is now complete and ready for submission. You have:

1. ✅ Working extension
2. ✅ Professional code
3. ✅ Complete documentation
4. ✅ Error handling
5. ✅ Settings management
6. ✅ Multiple AI providers

**Estimated evaluation time: 5 minutes**

The evaluator will:
1. Load your extension
2. Open a meeting
3. Click to capture
4. See summary generated
5. Download results
6. Check code quality

Everything should work smoothly!

---

**Congratulations! You've built a professional browser extension!** 🎉

Need help? Check the README.md troubleshooting section.
