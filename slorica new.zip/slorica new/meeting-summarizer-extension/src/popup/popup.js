/**
 * Meeting Summarizer - Popup Script
 * Handles UI interactions and communicates with content script and service worker
 */

// ============ DOM Elements ============
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const statusBadge = document.getElementById('status');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const loadingState = document.getElementById('loadingState');
const summaryState = document.getElementById('summaryState');
const errorState = document.getElementById('errorState');
const errorMessage = document.getElementById('errorMessage');
const retryBtn = document.getElementById('retryBtn');
const settingsLink = document.getElementById('settingsLink');

// Summary elements
const summaryText = document.getElementById('summaryText');
const keyPointsSection = document.getElementById('keyPointsSection');
const keyPointsList = document.getElementById('keyPointsList');
const actionItemsSection = document.getElementById('actionItemsSection');
const actionItemsList = document.getElementById('actionItemsList');
const transcriptInfo = document.getElementById('transcriptInfo');
const downloadBtn = document.getElementById('downloadBtn');
const copyBtn = document.getElementById('copyBtn');
const newBtn = document.getElementById('newBtn');

// ============ State ============
let isCapturing = false;
let currentTranscript = '';
let currentSummary = null;

// ============ Event Listeners ============
startBtn.addEventListener('click', handleStartCapture);
stopBtn.addEventListener('click', handleStopCapture);
downloadBtn.addEventListener('click', handleDownload);
copyBtn.addEventListener('click', handleCopy);
newBtn.addEventListener('click', handleNewSummary);
retryBtn.addEventListener('click', handleStartCapture);
settingsLink.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

// ============ Functions ============

/**
 * Start capturing captions from the meeting
 */
async function handleStartCapture() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // Check if we're on a supported meeting platform
    if (!isSupportedPlatform(tab.url)) {
      showError('Please open a Google Meet, Zoom, or Teams meeting first.');
      return;
    }

    // Inject content script first
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['src/content/content.js']
      });
      console.log('[Meeting Summarizer] Content script injected');
    } catch (injectError) {
      console.warn('[Meeting Summarizer] Content script injection failed (may already be loaded):', injectError);
    }

    // Wait a moment for script to load
    await new Promise(resolve => setTimeout(resolve, 200));

    // Send start message
    chrome.tabs.sendMessage(tab.id, { action: 'startCapture' }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('[Meeting Summarizer] Message error:', chrome.runtime.lastError);
        showError('Failed to start capturing. Refresh the meeting page and try again.');
        return;
      }

      if (response?.status === 'capturing' || response?.status === 'alreadyCapturing') {
        isCapturing = true;
        updateUI('capturing');
        console.log('[Meeting Summarizer] Capturing started');
      } else {
        showError('Unable to start capture. Refresh the meeting page.');
      }
    });

  } catch (error) {
    console.error('[Meeting Summarizer] Error:', error);
    showError('An error occurred: ' + error.message);
  }
}

/**
 * Stop capturing and send transcript for processing
 */
async function handleStopCapture() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    chrome.tabs.sendMessage(tab.id, { action: 'stopCapture' }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('[Meeting Summarizer] Message error:', chrome.runtime.lastError);
        showError('Failed to stop capturing. Refresh the page and try again.');
        return;
      }

      if (!response) {
        showError('No response from the meeting page. Make sure captions are enabled and the page is supported.');
        return;
      }

      const transcript = typeof response.transcript === 'string'
        ? response.transcript.trim()
        : '';

      if (!transcript) {
        showError('No transcript was captured. Make sure live captions are enabled in the meeting page and try again.');
        updateUI('ready');
        return;
      }

      currentTranscript = transcript;

      if (currentTranscript.length < 20) {
        showError('Not enough transcript captured. Make sure live captions are enabled and the meeting audio is audible.');
        return;
      }

      isCapturing = false;
      updateUI('processing');
      processTranscript(currentTranscript);
    });
  } catch (error) {
    console.error('[Meeting Summarizer] Error:', error);
    showError('An error occurred: ' + error.message);
  }
}

/**
 * Send transcript to service worker for summarization
 */
function processTranscript(transcript) {
  if (!transcript || transcript.length < 20) {
    showError('Transcript is too short. Need at least 20 characters.');
    return;
  }

  showState('loading');
  updateUI('processing');

  // Send to service worker
  chrome.runtime.sendMessage(
    {
      action: 'processTranscript',
      transcript: transcript
    },
    (response) => {
      if (chrome.runtime.lastError) {
        console.error('[Meeting Summarizer] Error:', chrome.runtime.lastError);
        showError('Failed to process transcript: ' + chrome.runtime.lastError.message);
        return;
      }

      if (!response) {
        showError('No response from background processor. Try again or reload the extension.');
        return;
      }

      if (response.success === false) {
        const message = response.error || 'Unknown error while summarizing.';
        console.error('[Meeting Summarizer] Summarization failed:', message);
        showError('Summarization failed: ' + message);
        updateUI('ready');
        return;
      }

      if (response.summary) {
        currentSummary = response.summary;
        displaySummary(response.summary);
        showState('summary');
        updateUI('complete');
      } else {
        showError('No summary returned. Try again with a longer transcript or enable captions.');
        updateUI('ready');
      }
    }
  );
}

/**
 * Display summary in the popup
 */
function displaySummary(summary) {
  // Main summary
  summaryText.textContent = summary.summary || 'No summary available.';

  // Key points
  if (summary.keyPoints && summary.keyPoints.length > 0) {
    keyPointsList.innerHTML = '';
    summary.keyPoints.forEach((point) => {
      const li = document.createElement('li');
      li.textContent = point;
      keyPointsList.appendChild(li);
    });
    keyPointsSection.style.display = 'block';
  } else {
    keyPointsSection.style.display = 'none';
  }

  // Action items
  if (summary.actionItems && summary.actionItems.length > 0) {
    actionItemsList.innerHTML = '';
    summary.actionItems.forEach((item) => {
      const li = document.createElement('li');
      const owner = item.owner || 'Unassigned';
      const task = item.task || item;
      li.innerHTML = `<strong>${escapeHtml(owner)}:</strong> ${escapeHtml(task)}`;
      actionItemsList.appendChild(li);
    });
    actionItemsSection.style.display = 'block';
  } else {
    actionItemsSection.style.display = 'none';
  }

  // Transcript info
  transcriptInfo.textContent = `Transcript length: ${currentTranscript.length} characters`;
}

/**
 * Download summary as JSON
 */
function handleDownload() {
  if (!currentSummary) {
    alert('No summary to download.');
    return;
  }

  const dataToDownload = {
    timestamp: new Date().toISOString(),
    ...currentSummary
  };

  const json = JSON.stringify(dataToDownload, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `meeting-summary-${Date.now()}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  console.log('[Meeting Summarizer] Summary downloaded');
}

/**
 * Copy summary to clipboard
 */
function handleCopy() {
  if (!currentSummary) {
    alert('No summary to copy.');
    return;
  }

  const textToCopy = `MEETING SUMMARY
${new Date().toLocaleString()}

${currentSummary.summary}

KEY POINTS:
${(currentSummary.keyPoints || []).map(kp => `• ${kp}`).join('\n')}

ACTION ITEMS:
${(currentSummary.actionItems || []).map(ai => `□ ${ai.owner || 'Unassigned'}: ${ai.task || ai}`).join('\n')}`;

  navigator.clipboard.writeText(textToCopy)
    .then(() => {
      alert('Summary copied to clipboard!');
      console.log('[Meeting Summarizer] Summary copied');
    })
    .catch((error) => {
      console.error('[Meeting Summarizer] Copy error:', error);
      alert('Failed to copy to clipboard.');
    });
}

/**
 * Start a new summary (reset UI)
 */
function handleNewSummary() {
  isCapturing = false;
  currentTranscript = '';
  currentSummary = null;
  showState('idle');
  updateUI('ready');
}

/**
 * Show error message
 */
function showError(message) {
  errorMessage.textContent = message;
  showState('error');
  updateUI('error');
}

/**
 * Update UI states
 */
function showState(state) {
  loadingState.style.display = state === 'loading' ? 'block' : 'none';
  summaryState.style.display = state === 'summary' ? 'block' : 'none';
  errorState.style.display = state === 'error' ? 'block' : 'none';
  startBtn.parentElement.style.display = state === 'idle' ? 'flex' : 'none';
}

/**
 * Update status badge and buttons
 */
function updateUI(state) {
  switch (state) {
    case 'ready':
      statusDot.className = 'status-dot';
      statusDot.classList.remove('active', 'success');
      statusText.textContent = 'Ready';
      startBtn.disabled = false;
      stopBtn.disabled = true;
      break;

    case 'capturing':
      statusDot.className = 'status-dot active';
      statusText.textContent = '🔴 Recording...';
      startBtn.disabled = true;
      stopBtn.disabled = false;
      break;

    case 'processing':
      statusDot.className = 'status-dot active';
      statusText.textContent = '⏳ Processing...';
      startBtn.disabled = true;
      stopBtn.disabled = true;
      break;

    case 'complete':
      statusDot.className = 'status-dot success';
      statusText.textContent = '✅ Complete';
      startBtn.disabled = false;
      stopBtn.disabled = true;
      break;

    case 'error':
      statusDot.className = 'status-dot';
      statusDot.style.background = '#ef4444';
      statusText.textContent = '❌ Error';
      startBtn.disabled = false;
      stopBtn.disabled = true;
      break;
  }
}

/**
 * Check if current tab is a supported platform
 */
function isSupportedPlatform(url) {
  return /meet\.google\.com|teams\.microsoft\.com|zoom\.us/.test(url);
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/**
 * Initialize popup
 */
function initializePopup() {
  showState('idle');
  updateUI('ready');
  console.log('[Meeting Summarizer] Popup initialized');
}

// Initialize when popup opens
document.addEventListener('DOMContentLoaded', initializePopup);

console.log('[Meeting Summarizer] Popup script loaded');
