/**
 * Meeting Summarizer - Service Worker
 * Handles API calls and background processing
 */

console.log('[Meeting Summarizer] Service Worker loaded');

// ============ Configuration ============
const API_TIMEOUT = 60000; // 60 seconds
const MAX_TRANSCRIPT_LENGTH = 10000; // Max characters to send to API
const RATE_LIMIT_DELAY = 1000; // 1 second between API calls

let lastAPICallTime = 0;

// ============ Message Listener ============
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  try {
    if (request.action === 'testHuggingFace') {
      (async () => {
        try {
          const { apiKey = '' } = await chrome.storage.sync.get ? await new Promise(r => chrome.storage.sync.get({ apiKey: '' }, r)) : { apiKey: '' };
          const headers = { 'Content-Type': 'application/json' };
          if (apiKey && apiKey.trim()) headers['Authorization'] = 'Bearer ' + apiKey.trim();

          const response = await fetchWithTimeout(
            'https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1',
            {
              method: 'POST',
              headers,
              body: JSON.stringify({ inputs: `Summarize this meeting: ${request.transcript || 'Test transcript'}` })
            },
            API_TIMEOUT
          );

          if (!response.ok) {
            const text = await response.text().catch(() => '');
            if (response.status === 401 || response.status === 403) {
              sendResponse({ success: false, error: 'Authentication error: please add a HuggingFace token in options.' });
              return;
            }
            sendResponse({ success: false, error: `HuggingFace error ${response.status}: ${response.statusText} ${text}` });
            return;
          }

          // quick validation
          const data = await response.json().catch(() => null);
          if (!data) {
            sendResponse({ success: false, error: 'Invalid response from HuggingFace' });
            return;
          }

          sendResponse({ success: true });
        } catch (err) {
          sendResponse({ success: false, error: err.message });
        }
      })();

      return true;
    }
    if (request.action === 'processTranscript') {
      processTranscript(request.transcript)
        .then((summary) => {
          sendResponse({ 
            success: true, 
            summary: summary 
          });
        })
        .catch((error) => {
          console.error('[Meeting Summarizer] Processing error:', error);
          sendResponse({ 
            success: false, 
            error: error.message 
          });
        });

      // Return true to indicate we'll send response asynchronously
      return true;
    }
  } catch (error) {
    console.error('[Meeting Summarizer] Error handling message:', error);
    sendResponse({ 
      success: false, 
      error: error.message 
    });
  }
});

// ============ Main Processing Function ============
async function processTranscript(transcript) {
  if (!transcript || transcript.length < 20) {
    throw new Error('Transcript is too short (minimum 20 characters)');
  }

  console.log('[Meeting Summarizer] Processing transcript:', transcript.length, 'characters');

  // Truncate transcript if too long
  const processedTranscript = transcript.substring(0, MAX_TRANSCRIPT_LENGTH);
  if (processedTranscript.length < transcript.length) {
    console.warn('[Meeting Summarizer] Transcript truncated from', transcript.length, 'to', processedTranscript.length);
  }

  // Get settings from storage
  const { provider, apiKey } = await chrome.storage.sync.get({
    provider: 'huggingface',
    apiKey: ''
  });

  console.log('[Meeting Summarizer] Using provider:', provider);

  // Route to appropriate API
  let summary;
  if (provider === 'claude' && apiKey) {
    summary = await summarizeWithClaude(processedTranscript, apiKey);
  } else {
    summary = await summarizeWithHuggingFace(processedTranscript, apiKey);
  }

  // Save to history
  await saveMeetingToHistory(summary, processedTranscript.length);

  return summary;
}

// ============ Claude API ============
async function summarizeWithClaude(transcript, apiKey) {
  if (!apiKey || !apiKey.trim()) {
    throw new Error('Claude API key not configured. Go to settings.');
  }

  console.log('[Meeting Summarizer] Calling Claude API...');

  const prompt = `You are a professional meeting summarizer. Analyze the following meeting transcript and provide:

1. A concise 2-3 sentence summary
2. Key points (5-7 bullet points)
3. Action items with assigned owners

IMPORTANT: Return ONLY valid JSON in this exact format (no markdown, no code blocks):
{
  "summary": "Your 2-3 sentence summary here",
  "keyPoints": ["Point 1", "Point 2", "Point 3"],
  "actionItems": [
    {"owner": "Person name", "task": "What they need to do"},
    {"owner": "Person name", "task": "What they need to do"}
  ]
}

Meeting Transcript:
${transcript}`;

  try {
    const response = await fetchWithTimeout(
      'https://api.anthropic.com/v1/messages',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-haiku-3-5',
          max_tokens: 1024,
          messages: [{
            role: 'user',
            content: prompt
          }]
        })
      },
      API_TIMEOUT
    );

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Claude API error: ${errorData.error?.message || response.statusText}`);
    }

    const data = await response.json();
    const responseText = data.content[0]?.text || '';

    // Parse JSON response
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('Claude response did not contain valid JSON');
    }

    const parsed = JSON.parse(jsonMatch[0]);
    console.log('[Meeting Summarizer] Claude summary generated successfully');
    return parsed;

  } catch (error) {
    console.error('[Meeting Summarizer] Claude API error:', error);
    throw new Error('Failed to generate summary with Claude: ' + error.message);
  }
}

// ============ HuggingFace API ============
async function summarizeWithHuggingFace(transcript, apiKey = '') {
  console.log('[Meeting Summarizer] Calling HuggingFace API...');

  const prompt = `You are a professional meeting summarizer. Do not include any extra text or markdown. Respond ONLY with valid JSON using this exact structure:
{
  "summary": "Brief 2-3 sentence summary of the meeting",
  "keyPoints": ["Point 1", "Point 2", "Point 3"],
  "actionItems": [{"owner": "Name", "task": "Action item description"}]
}

Transcript:
${transcript}`;
  console.log('[Meeting Summarizer] Prompt length:', prompt.length);

  try {
    const headers = { 'Content-Type': 'application/json' };
    if (apiKey && apiKey.trim()) headers['Authorization'] = 'Bearer ' + apiKey.trim();

    const response = await fetchWithTimeout(
      'https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1',
      {
        method: 'POST',
        headers,
        body: JSON.stringify({
          inputs: prompt,
          parameters: {
            max_new_tokens: 500,
            temperature: 0.7
          }
        })
      },
      API_TIMEOUT
    );

    if (!response.ok) {
      const errorText = await response.text();
      if (response.status === 401 || response.status === 403) {
        throw new Error(
          `HuggingFace authentication error: ${response.status} ${response.statusText}. ` +
          'A free HuggingFace token is usually required. Create one at https://huggingface.co/settings/tokens and paste it in the extension settings.'
        );
      }
      throw new Error(`HuggingFace API error: ${response.status} ${response.statusText} - ${errorText}`);
    }

    const data = await response.json();
    const responseText = data[0]?.generated_text || data.generated_text || '';

    // Extract JSON from response
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('HuggingFace response did not contain valid JSON. Response: ' + responseText);
    }

    const parsed = JSON.parse(jsonMatch[0]);
    console.log('[Meeting Summarizer] HuggingFace summary generated successfully');
    return parsed;

  } catch (error) {
    console.log('[Meeting Summarizer] HuggingFace API error:', error);
    // If it's an authentication error, surface it to the UI so user can add a token
    const msg = (error && error.message) ? error.message.toLowerCase() : '';
    if (msg.includes('authentication') || msg.includes('401') || msg.includes('403')) {
      throw new Error('HuggingFace authentication required: please add a valid token in Options. ' + error.message);
    }

    // For other transient/network errors, fall back to a simple local summary
    console.warn('[Meeting Summarizer] Falling back to local summary due to HF error');
    try {
      const fallback = generateFallbackSummary(transcript, transcript);
      // mark fallback so UI/logs can indicate it
      fallback._fallback = true;
      return fallback;
    } catch (fbErr) {
      console.error('[Meeting Summarizer] Fallback summary failed:', fbErr);
      throw new Error('Failed to generate summary: ' + error.message);
    }
  }
}

// ============ Fallback Summary Generation ============
function generateFallbackSummary(text, transcript) {
  // Extract sentences
  const sentences = transcript.match(/[^.!?]+[.!?]+/g) || [];
  
  // Simple summary: first and last sentences
  let summary = 'Meeting summary: ';
  if (sentences.length > 0) {
    summary += sentences[0].trim();
    if (sentences.length > 1) {
      summary += ' ' + sentences[sentences.length - 1].trim();
    }
  } else {
    summary += transcript.substring(0, 100) + '...';
  }

  // Key points: longer sentences
  const keyPoints = sentences
    .filter(s => s.length > 50)
    .slice(0, 3)
    .map(s => s.trim());

  return {
    summary: summary.substring(0, 300),
    keyPoints: keyPoints.length > 0 ? keyPoints : ['Meeting discussed multiple topics'],
    actionItems: [
      { owner: 'Team', task: 'Review meeting notes' }
    ]
  };
}

// ============ Utility Functions ============

/**
 * Fetch with timeout
 */
async function fetchWithTimeout(url, options, timeout = API_TIMEOUT) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);

  try {
    // Apply rate limiting
    const now = Date.now();
    const timeSinceLastCall = now - lastAPICallTime;
    if (timeSinceLastCall < RATE_LIMIT_DELAY) {
      await new Promise(resolve => 
        setTimeout(resolve, RATE_LIMIT_DELAY - timeSinceLastCall)
      );
    }
    lastAPICallTime = Date.now();

    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });

    clearTimeout(id);
    return response;

  } catch (error) {
    clearTimeout(id);
    if (error.name === 'AbortError') {
      throw new Error('Request timeout - try again or check your connection');
    }
    throw error;
  }
}

/**
 * Save meeting to history
 */
async function saveMeetingToHistory(summary, transcriptLength) {
  try {
    const { meetingHistory = [] } = await chrome.storage.sync.get('meetingHistory');

    const record = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      transcriptLength: transcriptLength,
      summary: summary.summary,
      keyPointsCount: summary.keyPoints?.length || 0,
      actionItemsCount: summary.actionItems?.length || 0
    };

    meetingHistory.unshift(record);

    // Keep only last 50 meetings
    if (meetingHistory.length > 50) {
      meetingHistory.pop();
    }

    await chrome.storage.sync.set({ meetingHistory });
    console.log('[Meeting Summarizer] Meeting saved to history');

  } catch (error) {
    console.warn('[Meeting Summarizer] Failed to save to history:', error);
  }
}

console.log('[Meeting Summarizer] Service Worker initialized and ready');
