﻿
/**
 * Content Script - Meeting Summarizer
 * Captures live captions from meeting pages
 */

console.log('[MS] Content script loaded');

// Improved caption capture: only visible, caption-like elements, with debug overlay support
let captureActive = false;
let transcript = [];
let transcriptSet = new Set();
let mutationObserver = null;
let debugOverlay = null;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'startCapture') {
    startCapture();
    sendResponse({ status: 'capturing' });
  } else if (request.action === 'stopCapture') {
    const result = stopCapture();
    sendResponse({ status: 'stopped', transcript: result });
  } else if (request.action === 'dumpCaptured') {
    sendResponse({ transcript: transcript.join('\n') });
  }
});

function startCapture() {
  if (captureActive) return;
  captureActive = true;
  transcript = [];
  transcriptSet = new Set();

  console.log('[MS] Starting capture (improved heuristics)');

  captureCandidates();

  mutationObserver = new MutationObserver(debounce(captureCandidates, 150));
  mutationObserver.observe(document.documentElement, {
    subtree: true,
    childList: true,
    characterData: true,
    attributes: true
  });

  // create debug overlay if enabled
  try {
    chrome.storage && chrome.storage.sync && chrome.storage.sync.get({ debug: false }, (opts) => {
      if (opts.debug) createDebugOverlay();
    });
  } catch (e) {
    // ignore in pages without chrome.storage
  }
}

function stopCapture() {
  captureActive = false;
  if (mutationObserver) {
    mutationObserver.disconnect();
    mutationObserver = null;
  }
  removeDebugOverlay();

  const result = transcript.join('\n').trim();
  console.log(`[MS] Captured ${transcript.length} segments, ${result.length} chars`);
  return result;
}

function captureCandidates() {
  if (!captureActive) return;

  try {
    const candidates = new Set();

    // Priority 1: actual caption elements (aria-live, role=status)
    const captionSelectors = [
      '[aria-live="polite"]',
      '[aria-live="assertive"]',
      '[role="status"]',
      '[role="log"]',
      '[data-qa*="caption"]'
    ];

    captionSelectors.forEach((selector) => {
      try {
        document.querySelectorAll(selector).forEach((el) => {
          if (isElementVisible(el)) candidates.add(el);
        });
      } catch (error) {}
    });

    // Priority 2: only bottom 20% of screen (where captions actually appear)
    // and only smallish containers (not full-width UI panels)
    const allTextContainers = document.querySelectorAll('div, span');
    allTextContainers.forEach((el) => {
      try {
        const rect = el.getBoundingClientRect();
        // Only bottom 20% and reasonable caption-like size
        if (rect.bottom < window.innerHeight * 0.8) return;
        if (rect.top > window.innerHeight) return;
        if (rect.width < 100 || rect.width > window.innerWidth * 0.9) return;  // not too wide
        if (rect.height < 14 || rect.height > 100) return;  // reasonable height
        if (!isElementVisible(el)) return;
        const txt = (el.innerText || el.textContent || '').trim();
        if (txt.length < 2 || txt.length > 500) return;
        candidates.add(el);
      } catch (error) {}
    });

    console.log('[MS] Candidate elements found:', candidates.size);

    for (let el of candidates) {
      if (!isElementVisible(el)) continue;
      const text = (el.innerText || el.textContent || '').trim();
      if (!text) continue;

      const lines = text.split(/\n+/).map(line => line.trim()).filter(Boolean);
      for (let line of lines) {
        if (line.length < 2 || line.length > 500) continue;
        if (transcriptSet.has(line)) continue;
        if (looksLikeUIList(line)) continue;
        if (isJunk(line)) continue;
        if (!isSpeech(line)) {
          console.log('[MS] Rejected:', line.substring(0, 50));
          continue;
        }

        transcriptSet.add(line);
        transcript.push(line);
        if (debugOverlay) appendDebug(line);
        console.log('[MS] ✓ Captured:', line);
      }
    }
  } catch (err) {
    console.error('[MS] captureCandidates error', err);
  }
}

function isElementVisible(el) {
  try {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity || '1') < 0.1) return false;
    return true;
  } catch (e) { return false; }
}

function looksLikeUIList(text) {
  // Detect UI controls, settings, accessibility text, and UI lists
  const uiPatterns = [
    /Press.*Arrow/i,
    /Turn (on|off)/i,
    /ctrl\s*\+/i,
    /keyboard_|settings|_hand|_end|call_end|more_vert|videocam|microphone|Share|screen|reaction|caption|Raise hand|Host controls|Meeting details|Chat|Leave call|Meeting tools/i,
    /Font (size|color)|Open caption|Caption language|Select language|hover tray|Escape to close/i,
    /^[A-Z][a-z]* (color|tone|format|size|settings)/i,
    /^(Okay|Understood|Got it|Yes|No)$/i,
    /Audio|Video|camera_arrow|Audio settings|Video settings/i,
    /fsz-|_nwqk-|[a-z]{3}-[a-z]{4}-[a-z]{3}/  // random token patterns
  ];

  for (let pattern of uiPatterns) {
    if (pattern.test(text)) return true;
  }

  // Detect long comma-separated lists (language menus, etc.)
  if (text.length > 200 && (text.match(/,/g) || []).length > 5) return true;

  return false;
}

function isSpeech(text) {
  // Reject pure numbers/timestamps
  if (/^[\d:.,\-,\s]*$/.test(text)) return false;
  
  // Reject if it looks like UI/settings text
  if (looksLikeUIList(text)) return false;
  
  const words = text.split(/\s+/).filter(w => w.length > 1);
  const first = words[0] ? words[0].toLowerCase() : '';
  
  // Strict UI-only words
  const strictUIOnly = new Set([
    'start','stop','record','camera','mic','unmute','mute','settings','help','menu','home',
    'share','end','leave','join','close','back','next','previous','okay','yes','no','turn',
    'press','audio','video','chat','call','meeting','screen','hand','tools','details'
  ]);
  
  if (strictUIOnly.has(first) && words.length <= 2) return false;
  
  // Must have at least 2 words for multi-word phrases
  // OR be 12+ chars and look natural
  if (words.length >= 2) {
    // But still filter out phrases that are mostly UI words
    const uiWordCount = words.filter(w => strictUIOnly.has(w.toLowerCase())).length;
    if (uiWordCount >= words.length - 1) return false;  // mostly UI words
    return true;
  }
  
  if (text.length >= 12) return true;
  return false;
}

function isJunk(text) {
  if (/[[\]{}/\\\"'`:;,<>|&^%$#@!~?*()+=_-]{5,}/.test(text)) return true;
  if (/^\d+$/.test(text)) return true;
  if (/^\d{1,2}:\d{2}(:\d{2})?$/.test(text)) return true;
  const specialCount = (text.match(/[^\w\s.,!?-]/g) || []).length;
  if (specialCount > text.length * 0.25) return true;
  return false;
}

// Debug overlay
function createDebugOverlay() {
  if (debugOverlay) return;
  debugOverlay = document.createElement('div');
  debugOverlay.style.position = 'fixed';
  debugOverlay.style.right = '8px';
  debugOverlay.style.bottom = '8px';
  debugOverlay.style.zIndex = 2147483647;
  debugOverlay.style.maxWidth = '360px';
  debugOverlay.style.maxHeight = '240px';
  debugOverlay.style.overflow = 'auto';
  debugOverlay.style.background = 'rgba(0,0,0,0.7)';
  debugOverlay.style.color = '#fff';
  debugOverlay.style.fontSize = '12px';
  debugOverlay.style.padding = '8px';
  debugOverlay.style.borderRadius = '6px';
  debugOverlay.style.fontFamily = 'sans-serif';
  debugOverlay.id = 'ms-debug-overlay';
  debugOverlay.innerText = 'Captured captions:';
  document.body.appendChild(debugOverlay);
}

function appendDebug(line) {
  if (!debugOverlay) return;
  const el = document.createElement('div');
  el.style.marginTop = '6px';
  el.textContent = line;
  debugOverlay.appendChild(el);
  // keep only last 50
  while (debugOverlay.childNodes.length > 60) debugOverlay.removeChild(debugOverlay.firstChild);
}

function removeDebugOverlay() {
  if (!debugOverlay) return;
  try { debugOverlay.remove(); } catch (e) {}
  debugOverlay = null;
}

function debounce(fn, wait) {
  let t = null;
  return function() {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, arguments), wait);
  };
}

console.log('[MS] Content script ready (improved)');
