/**
 * Meeting Summarizer - Options Page Script
 * Handles settings, API key management, and usage history
 */

console.log('[Meeting Summarizer] Options page loaded');

// ============ DOM Elements ============
const providerSelect = document.getElementById('provider');
const apiKeyInput = document.getElementById('apiKey');
const claudeSection = document.getElementById('claudeSection');
const saveBtn = document.getElementById('saveBtn');
const testBtn = document.getElementById('testBtn');
const resetBtn = document.getElementById('resetBtn');
const successBox = document.getElementById('successBox');
const errorBox = document.getElementById('errorBox');
const statusMessage = document.getElementById('statusMessage');
const statsText = document.getElementById('statsText');
const historyContainer = document.getElementById('historyContainer');
const historyList = document.getElementById('historyList');

// ============ Event Listeners ============
document.addEventListener('DOMContentLoaded', loadSettings);
providerSelect.addEventListener('change', toggleClaudeSection);
saveBtn.addEventListener('click', saveSettings);
testBtn.addEventListener('click', testAPI);
resetBtn.addEventListener('click', resetSettings);

// ============ Functions ============

/**
 * Load settings from storage
 */
function loadSettings() {
  chrome.storage.sync.get({
    provider: 'huggingface',
    apiKey: '',
    meetingHistory: []
  }, (items) => {
    try {
      providerSelect.value = items.provider || 'huggingface';
      if (items.apiKey) {
        apiKeyInput.value = items.apiKey;
      }

      toggleClaudeSection();
      updateStats(items.meetingHistory);

      console.log('[Meeting Summarizer] Settings loaded');
    } catch (error) {
      console.error('[Meeting Summarizer] Error loading settings:', error);
      showError('Failed to load settings');
    }
  });
}

/**
 * Toggle Claude section visibility
 */
function toggleClaudeSection() {
  if (providerSelect.value === 'claude') {
    claudeSection.style.display = 'block';
  } else {
    claudeSection.style.display = 'none';
  }
}

/**
 * Save settings
 */
function saveSettings() {
  const provider = providerSelect.value;
  const apiKey = apiKeyInput.value.trim();

  // Validation
  if (provider === 'claude') {
    if (!apiKey) {
      showError('Claude API key is required for this provider');
      return;
    }
    if (!apiKey.startsWith('sk-ant-')) {
      showError('API key should start with "sk-ant-"');
      return;
    }
  }

  // Disable button while saving
  saveBtn.disabled = true;
  saveBtn.textContent = 'Saving...';

  try {
    chrome.storage.sync.set({
      provider: provider,
      apiKey: apiKey
    }, () => {
      if (chrome.runtime.lastError) {
        showError('Failed to save settings: ' + chrome.runtime.lastError.message);
      } else {
        showSuccess('Settings saved successfully!');
        console.log('[Meeting Summarizer] Settings saved');
      }

      // Re-enable button
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save Settings';
    });
  } catch (error) {
    console.error('[Meeting Summarizer] Error saving settings:', error);
    showError('An error occurred while saving');
    saveBtn.disabled = false;
    saveBtn.textContent = 'Save Settings';
  }
}

/**
 * Test API connection
 */
async function testAPI() {
  const provider = providerSelect.value;
  const apiKey = apiKeyInput.value.trim();

  if (provider === 'claude' && !apiKey) {
    showError('Please enter your Claude API key first');
    return;
  }

  testBtn.disabled = true;
  testBtn.textContent = 'Testing...';

  try {
    const testTranscript = 'This is a test meeting. We discussed project goals and next steps.';

    if (provider === 'claude') {
      await testClaudeAPI(apiKey, testTranscript);
    } else {
      await testHuggingFaceAPI(testTranscript);
    }

    showSuccess('✅ API connection successful!');
    console.log('[Meeting Summarizer] API test passed');
  } catch (error) {
    console.error('[Meeting Summarizer] API test error:', error);
    showError('API test failed: ' + error.message);
  } finally {
    testBtn.disabled = false;
    testBtn.textContent = 'Test API';
  }
}

/**
 * Test Claude API
 */
async function testClaudeAPI(apiKey, transcript) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-haiku-3-5',
      max_tokens: 200,
      messages: [{
        role: 'user',
        content: `Summarize this meeting in one sentence: ${transcript}`
      }]
    })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error?.message || 'API request failed');
  }

  const data = await response.json();
  if (!data.content || data.content.length === 0) {
    throw new Error('Invalid API response');
  }

  console.log('[Meeting Summarizer] Claude API test response:', data.content[0].text);
}

/**
 * Test HuggingFace API
 */
async function testHuggingFaceAPI(transcript) {
  // Run the test via the background service worker to avoid CORS issues
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: 'testHuggingFace', transcript }, (resp) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (!resp) return reject(new Error('No response from background'));
      if (resp.success) return resolve();
      return reject(new Error(resp.error || 'Unknown error from HuggingFace test'));
    });
  });
}

/**
 * Reset all settings
 */
function resetSettings() {
  if (!confirm('Are you sure you want to reset all settings and history? This cannot be undone.')) {
    return;
  }

  resetBtn.disabled = true;
  resetBtn.textContent = 'Resetting...';

  chrome.storage.sync.clear(() => {
    if (chrome.runtime.lastError) {
      showError('Failed to reset: ' + chrome.runtime.lastError.message);
      resetBtn.disabled = false;
      resetBtn.textContent = 'Reset All Settings';
    } else {
      showSuccess('✅ All settings have been reset!');
      loadSettings();
      apiKeyInput.value = '';
      providerSelect.value = 'huggingface';
      toggleClaudeSection();
      console.log('[Meeting Summarizer] Settings reset');
      
      setTimeout(() => {
        resetBtn.disabled = false;
        resetBtn.textContent = 'Reset All Settings';
      }, 2000);
    }
  });
}

/**
 * Update statistics display
 */
function updateStats(history) {
  if (!history || history.length === 0) {
    statsText.textContent = 'No meetings recorded yet. Start capturing to see statistics here.';
    historyContainer.style.display = 'none';
    return;
  }

  const totalMeetings = history.length;
  const totalActions = history.reduce((sum, h) => sum + (h.actionItemsCount || 0), 0);
  const avgLength = Math.round(
    history.reduce((sum, h) => sum + (h.transcriptLength || 0), 0) / totalMeetings
  );

  statsText.innerHTML = `
    <strong>${totalMeetings}</strong> meeting${totalMeetings !== 1 ? 's' : ''} summarized<br>
    <strong>${totalActions}</strong> action item${totalActions !== 1 ? 's' : ''} extracted<br>
    Average transcript: <strong>${avgLength}</strong> characters
  `;

  // Display history
  historyList.innerHTML = '';
  history.slice(0, 10).forEach((item) => {
    const date = new Date(item.timestamp);
    const timeStr = date.toLocaleString();
    const li = document.createElement('li');
    li.className = 'history-item';
    li.innerHTML = `
      <strong>${escapeHtml(item.summary?.substring(0, 50) || 'Untitled')}...</strong><br>
      <span class="timestamp">${timeStr} • ${item.transcriptLength} chars</span>
    `;
    historyList.appendChild(li);
  });

  historyContainer.style.display = 'block';
}

/**
 * Show success message
 */
function showSuccess(message) {
  successBox.textContent = message;
  successBox.style.display = 'block';
  errorBox.style.display = 'none';

  setTimeout(() => {
    successBox.style.display = 'none';
  }, 4000);
}

/**
 * Show error message
 */
function showError(message) {
  errorBox.textContent = '❌ ' + message;
  errorBox.style.display = 'block';
  successBox.style.display = 'none';

  setTimeout(() => {
    errorBox.style.display = 'none';
  }, 4000);
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

console.log('[Meeting Summarizer] Options script ready');
